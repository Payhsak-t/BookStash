import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { RegisterService } from '../service/register.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user: User = new User();
  constructor(private registerService: RegisterService) { }
  registerForm: FormGroup;
  name: FormControl;
  dob: FormControl;
  gender: FormControl;
  genre: FormControl;
  phone: FormControl;
  email: FormControl;
  password: FormControl;
  users: Array<User> = [];
  ngOnInit() {
    this.email = new FormControl('', [Validators.required, Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")]);
    this.password = new FormControl('', [Validators.required, Validators.minLength(6)]);
    this.name = new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]);
    this.phone = new FormControl('', [Validators.required, Validators.minLength(10),Validators.maxLength(10)]);
    this.gender = new FormControl('', Validators.required);
    this.genre = new FormControl('', Validators.required);
    this.dob = new FormControl('', Validators.required);
    this.registerForm = new FormGroup({
      email: this.email,
      password: this.password,
      name: this.name,
      phone: this.phone,
      gender: this.gender,
      genre: this.genre,
      dob: this.dob
    })
  }
  save() {
    this.user.email = this.registerForm.value.email;
    this.user.password = this.registerForm.value.password;
    this.user.name = this.registerForm.value.name;
    this.user.phone = this.registerForm.value.phone;
    this.user.gender = this.registerForm.value.gender;
    this.user.genre = this.registerForm.value.genre;
    this.user.dob = this.registerForm.value.dob;
    this.registerService.createUser(this.user).subscribe(
      data => {
        console.log(data);
      },
      error => console.log(error)
    );
    this.user = new User();
  }

  onSubmit() {
    this.save();
  }
}
